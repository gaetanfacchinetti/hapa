# hapa

This small projects called hapa for (Halo Package) aims to become a tool for analytical DM halo studies in cosmology and astrophysics. The goal will be to implement a python interfaced version of the FSL model.
